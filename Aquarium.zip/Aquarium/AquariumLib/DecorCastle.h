/**
 * @file DecorCastle.h
 * @author Paulina Bies
 *
 * Class for a Decor of type Castle
 *
 */

#ifndef AQUARIUM_DECORCASTLE_H
#define AQUARIUM_DECORCASTLE_H

#include "Item.h"


/**
 * Class for a Decor of type Castle
 */
class DecorCastle : public Item {
private:

public:

    /// Default constructor (disabled)
    DecorCastle() = delete;

    /// Copy constructor (disabled)
    DecorCastle(const DecorCastle &) = delete;

    /// Assignment operator (disabled)
    void operator=(const DecorCastle &) = delete;

    ///Copy constructor
    DecorCastle(Aquarium* aquarium);

    wxXmlNode* XmlSave(wxXmlNode* node) override;



};

#endif //AQUARIUM_DECORCASTLE_H
