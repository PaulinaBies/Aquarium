/**
 * @file Fish.cpp
 * @author Paulina Bies
 */

#include "pch.h"
#include "Fish.h"
#include "Aquarium.h"



/// Maximum speed in the X direction in
/// in pixels per second
const double MaxSpeedX = 50;

/// Minimum speed in the X direction in
/// pixels per second
const double MinSpeedX = 20;


/**
 * Constructor
 * @param aquarium The aquarium we are in
 * @param filename Filename for the image we use
 */
Fish::Fish(Aquarium *aquarium, const std::wstring &filename) :
        Item(aquarium, filename)
{
    std::uniform_real_distribution<> distribution(MinSpeedX, MaxSpeedX);
    mSpeedX = distribution(aquarium->GetRandom());
    mSpeedY = distribution(aquarium->GetRandom());;
}


/**
 * Handle updates in time of our fish
 *
 * This is called before we draw and allows us to
 * move our fish. We add our speed times the amount
 * of time that has elapsed.
 * @param elapsed Time elapsed since the class call
 */
void Fish::Update(double elapsed)
{

    SetLocation(GetX() + mSpeedX * elapsed,
            GetY() + mSpeedY * elapsed);

    //make sure fish doesn't go past right screen
    if (mSpeedX > 0 && GetX() >= (GetAquarium()->GetWidth() - 10 - (GetItemWidth()/2)))
    {
        mSpeedX = -mSpeedX;
        SetMirror(true);

    }

    //make sure fish doesn't go past left screen
    if (mSpeedX < 0 && GetX() <= GetItemWidth()/2 + 10)
    {
        mSpeedX = -mSpeedX;
        SetMirror(false);
    }

    //make sure fish doesn't go below screen
    if (mSpeedY > 0 && GetY() >= (GetAquarium()->GetHeight() + 10 - (GetItemHeight())))
    {
        mSpeedY = -mSpeedY;
        SetMirror(true);
    }

    //make sure fish doesn't go above screen
    if (mSpeedY < 0 && GetY() <=  GetItemHeight()/2 - 10)
    {
        mSpeedY = -mSpeedY;
    }

    //up and down movement for fish
    int yMovement = GetY();
    if (yMovement % 100 == 0)
    {
        mSpeedY = -mSpeedY;
    }

    //change speeds of fish
    //different speeds for each fish
    // some just speed up in either x or y direction
    if (yMovement % 300 == 0)
    {
        mSpeedX += IncreaseSpeedX();
        mSpeedY += IncreaseSpeedY();
    }


}

/**
 * Save this fish to an XML node
 * @param node The parent node we are going to be a child of
 * @return wxXmlNode that we saved the item into
 */
wxXmlNode* Fish::XmlSave(wxXmlNode* node)
{
    auto itemNode = Item::XmlSave(node);
    itemNode->AddAttribute(L"speedx", wxString::FromDouble(mSpeedX));
    itemNode->AddAttribute(L"speedy", wxString::FromDouble(mSpeedY));
    return itemNode;
}



/**
 * Load the attributes for an item node.
 *
 * loads the speed attributes for the fish
 * for specific items.
 *
 * @param node The Xml node we are loading the item from
 */
void Fish::XmlLoad(wxXmlNode *node)
{
    node->GetAttribute(L"speedx", L"0").ToDouble(&mSpeedX);
    node->GetAttribute(L"speedy", L"0").ToDouble(&mSpeedY);
}




