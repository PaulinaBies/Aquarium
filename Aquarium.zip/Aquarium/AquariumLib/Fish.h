/**
 * @file Fish.h
 * @author Paulina Bies
 *
 * Base class for a Fish Item
 *
 */

#ifndef AQUARIUM_FISH_H
#define AQUARIUM_FISH_H

#include "Item.h"



/**
 * Base class for a fish
 * This applies to all of the fish, but not the decor
 * items in the aquarium
 */
class Fish : public Item {
private:

    /// speed in the X direction in pixels/sec
    double mSpeedX = 0;

    /// speed in the X direction in pixels/sec
    double mSpeedY = 0;

protected:
    Fish(Aquarium* aquarium, const std::wstring& filename);


public:

    /// Default constructor (disabled)
    Fish() = delete;

    /// Copy constructor (disabled)
    Fish(const Fish &) = delete;

    /// Assignment operator
    void operator=(const Fish &) = delete;


    /**
     * Amount to increase speed (pixels/sec) in X direction
     * @return double amount to increase speed in X direction
     */
    virtual double IncreaseSpeedX() {return 0;};

    /**
     * Amount to increase speed (pixels/sec) in Y direction
     * @return double amount to increase speed in Y direction
     */
    virtual double IncreaseSpeedY() {return 0;};

    void Update(double elapsed) override;

    wxXmlNode* XmlSave(wxXmlNode* node) override;

    void XmlLoad(wxXmlNode* node) override;



};

#endif //AQUARIUM_FISH_H
