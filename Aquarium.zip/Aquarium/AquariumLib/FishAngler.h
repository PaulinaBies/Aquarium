/**
 * @file FishAngler.h
 * @author Paulina Bies
 *
 * Class for Angler fish
 */

#ifndef AQUARIUM_FISHANGLER_H
#define AQUARIUM_FISHANGLER_H

#include "Fish.h"

/**
 * Class for a fish of type Angler
 */
class FishAngler : public Fish {
private:

    ///Increase speed in Y direction
    double mIncreaseY = 15;

public:

    /// Default constructor (disabled)
    FishAngler() = delete;

    /// Copy constructor (disabled)
    FishAngler(const FishAngler &) = delete;

    /// Assignment operator (disabled)
    void operator=(const FishAngler &) = delete;

    ///Copy constructor
    FishAngler(Aquarium* aquarium);

    /**
     * Amount to increase speed (pixels/sec) in Y direction
     * @return double amount to increase speed in Y direction
     */
    double IncreaseSpeedY() override {return mIncreaseY;};

    wxXmlNode* XmlSave(wxXmlNode* node) override;



};


#endif //AQUARIUM_FISHANGLER_H
