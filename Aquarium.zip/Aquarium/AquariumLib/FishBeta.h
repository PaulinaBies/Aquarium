/**
 * @file FishBeta.h
 * @author Paulina Bies
 *
 * Class for a Beta Fish
 */

#ifndef AQUARIUM_FISHBETA_H
#define AQUARIUM_FISHBETA_H


#include "Fish.h"


/**
 * Class for a fish of type Beta
 */
class FishBeta : public Fish {
private:


    /// Increase speed in X direction (pixels/second)
    double mIncreaseX = 20;

public:

    /// Default constructor (disabled)
    FishBeta() = delete;

    /// Copy constructor (disabled)
    FishBeta(const FishBeta &) = delete;

    /// Assignment operator (disabled)
    void operator=(const FishBeta &) = delete;

    ///Copy constructor
    FishBeta(Aquarium* aquarium);


    /**
     * Amount to increase speed (pixels/sec) in x direction
     * @return amount to increase speed in X direction
     */
    double IncreaseSpeedX() override {return mIncreaseX;};

    wxXmlNode* XmlSave(wxXmlNode* node) override;



};

#endif //AQUARIUM_FISHBETA_H
