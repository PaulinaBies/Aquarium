/**
 * @file FishBubbles.cpp
 * @author Paulina Bies
 */

#include "pch.h"
#include "FishBubbles.h"
#include "Aquarium.h"


using namespace std;

/// Fish filename
const wstring FishBubblesImageName = L"images/bubbles.png";


/**
 * Constructor
 * @param aquarium Aquarium this fish is a member of
 */
FishBubbles::FishBubbles(Aquarium *aquarium) : Fish(aquarium, FishBubblesImageName)
{
}


/**
 * Save this fish to an XML node
 * @param node The parent node we are going to be a child of
 * @return wxXmlNode that we saved the item into
 */
wxXmlNode* FishBubbles::XmlSave(wxXmlNode* node)
{
    auto itemNode = Fish::XmlSave(node);
    itemNode->AddAttribute(L"type", L"bubbles");
    return itemNode;
}

