/**
 * @file FishBubbles.h
 * @author Paulina Bies
 *
 * Class for Fish Bubbles
 */

#ifndef AQUARIUM_FISHBUBBLES_H
#define AQUARIUM_FISHBUBBLES_H


#include "Fish.h"


/**
 * Class for a fish of type Bubbles
 */
class FishBubbles : public Fish {
private:

    /// Increase speed in Y direction (pixels/sec)
    double mIncreaseY = 10;

    /// Increase speed in X direction (pixels/sec)
    double mIncreaseX = 10;


public:

    /// Default constructor (disabled)
    FishBubbles() = delete;

    /// Copy constructor (disabled)
    FishBubbles(const FishBubbles &) = delete;

    /// Assignment operator (disabled)
    void operator=(const FishBubbles &) = delete;

    ///Copy constructor
    FishBubbles(Aquarium* aquarium);


    /**
     * Amount to increase speed (pixels/sec) in X direction
     * @return amount to increase speed in X direction
     */
    double IncreaseSpeedX() override {return mIncreaseX;};

    /**
     * Amount to increase speed (pixels/sec) in Y direction
     * @return amount to increase speed in Y direction
     */
    double IncreaseSpeedY() override {return mIncreaseY;};

    wxXmlNode* XmlSave(wxXmlNode* node) override;


};


#endif //AQUARIUM_FISHBUBBLES_H
