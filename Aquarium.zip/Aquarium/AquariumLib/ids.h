/**
 * @file ids.h
 * @author Paulina Bies
 *
 * ID values for the program
 */

#ifndef AQUARIUM_IDS_H
#define AQUARIUM_IDS_H

/**
 * ID values for the program
 */
enum IDs {
    IDM_ADDFISHBETA = wxID_HIGHEST + 1,
    IDM_ADDFISHANGLER = wxID_HIGHEST + 2,
    IDM_ADDFISHBUBBLES = wxID_HIGHEST + 3,
    IDM_ADDDECORCASTLE = wxID_HIGHEST + 4
};





#endif //AQUARIUM_IDS_H


