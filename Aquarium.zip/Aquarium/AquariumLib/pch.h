/**
 * @file pch.h
 * @author Paulina Bies
 *
 */

#ifndef AQUARIUM_PCH_H
#define AQUARIUM_PCH_H

#include <wx/wxprec.h>
#ifndef WX_PRECOMP
#include <wx/wx.h>
#include <wx/xml/xml.h>
#endif

#endif //AQUARIUM_PCH_H
