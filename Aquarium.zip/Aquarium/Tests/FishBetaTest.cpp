/**
 * @file FishBetaTest.cpp
 * @author Paulina Bies
 *
 * Test for FishBeata class
 *
 */

#include <pch.h>
#include "gtest/gtest.h"
#include <FishBeta.h>
#include <Aquarium.h>

/** Mock class for testing the Beta Fish Item */
class FishBetaMock : public FishBeta {
public:
    FishBetaMock(Aquarium *aquarium) : FishBeta(aquarium) {}

};


/**
 * Test for item Constructor
 */
TEST(FishBetaTest, Construct) {
    Aquarium aquarium;
    FishBetaMock fishBeta(&aquarium);
}




