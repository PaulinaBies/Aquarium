/**
 * @file main.cpp
 * @author Paulina Bies
 *
 * main file for Aquarium
 *
 */

#include "pch.h"
#include "AquariumApp.h"

wxIMPLEMENT_APP(AquariumApp);